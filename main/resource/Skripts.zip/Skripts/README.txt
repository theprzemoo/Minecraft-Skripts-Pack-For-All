📦 SKRIPTS

Autor: theprzemoo
GitHub: https://github.com/theprzemoo
Licencja: MIT License

Opis:
Ta paczka zawiera zestaw prostych i przejrzystych skryptów do Minecrafta,
napisanych w języku Skript (wersja 2.13.0+).
Wszystkie komendy i komunikaty są w języku polskim.

Wymagania (Testowane Na Tym):
- Skript 2.13.0
- Minecraft 1.21.5
- Żadne dodatki (addony) nie są wymagane

Cel projektu:
Stworzenie alternatywy dla pluginów – prostych rozwiązań opartych na skryptach,
oraz nauka programowania w Skripcie.

Zawartość paczki:
- broadcast.sk
- clearchat.sk
- day.sk
- enderchest.sk
- feed.sk
- fly.sk
- gm.sk
- god.sk
- heal.sk
- invsee.sk
- night.sk
- ping.sk
- repair.sk
- spawn.sk
- tpa.sk
- workbench.sk

Dziękuję za pobranie mojej paczki!
Jeśli chcesz wesprzeć projekt lub dodać własne pomysły – zajrzyj na GitHuba.
